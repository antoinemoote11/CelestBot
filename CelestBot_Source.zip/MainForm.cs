﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Windows.Forms;
using Windows.Globalization;
using Windows.Media.Ocr;
using Windows.Graphics.Imaging;
using Windows.Storage.Streams;

namespace CelestBot;

public sealed class MainForm : Form
{
    // Reuse the Windows OCR engine. Creating it for every full-screen scan and
    // every fallback crop adds noticeable latency without improving recognition.
    private static readonly Lazy<OcrEngine?> SharedOcrEngine = new(() =>
        OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
        ?? OcrEngine.TryCreateFromUserProfileLanguages());

    private readonly Button startButton = new() { Text = "DÉMARRER", Width = 150, Height = 50 };
    private readonly Button stopButton = new() { Text = "ARRÊTER", Width = 150, Height = 50, Enabled = false };
    private readonly Label status = new() { Text = "En attente", AutoSize = true };
    private readonly Label hpLabel = new() { Text = "HP : --", AutoSize = true };
    private readonly Label thresholdLabel = new() { Text = "Retour au village sous : 50 %", AutoSize = true };
    private readonly TrackBar thresholdTrackBar = new() { Minimum = 25, Maximum = 100, Value = 50, TickFrequency = 25, SmallChange = 1, LargeChange = 5, Width = 320, Height = 48 };
    private volatile int returnThreshold = 50;
    private CancellationTokenSource? cts;
    private bool busy;
    private double? lastHp;
    private DateTime lastHpAt = DateTime.MinValue;
    private int lowCount;

    public MainForm()
    {
        Text = "CelestBot";
        Width = 390;
        Height = 220;
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;

        var title = new Label
        {
            Text = "CELESTBOT",
            Font = new Font("Segoe UI", 18, FontStyle.Bold),
            AutoSize = true,
            Left = 25, Top = 18
        };

        startButton.Left = 25; startButton.Top = 65;
        stopButton.Left = 190; stopButton.Top = 65;
        status.Left = 25; status.Top = 120;
        thresholdLabel.Left = 25; thresholdLabel.Top = 150;
        thresholdTrackBar.Left = 25; thresholdTrackBar.Top = 172;
        hpLabel.Left = 25; hpLabel.Top = 220;
        thresholdTrackBar.Scroll += (_, _) =>
        {
            int v = thresholdTrackBar.Value;
            returnThreshold = v;
            thresholdLabel.Text = $"Retour au village sous : {v} %";
        };

        startButton.Click += (_, _) => StartBot();
        stopButton.Click += (_, _) => StopBot();
        Height = 305;
        Controls.AddRange([title, startButton, stopButton, status, thresholdLabel, thresholdTrackBar, hpLabel]);

        FormClosing += (_, _) => StopBot();
    }

    private void StartBot()
    {
        if (busy) return;
        busy = true;
        cts = new CancellationTokenSource();
        startButton.Enabled = false;
        stopButton.Enabled = true;
        SetStatus("Démarré. Place le jeu sur Chrome.");
        _ = Task.Run(() => LoopAsync(cts.Token));
    }

    private void StopBot()
    {
        cts?.Cancel();
        busy = false;
        startButton.Enabled = true;
        stopButton.Enabled = false;
        SetStatus("Arrêté");
    }

    private void SetStatus(string text)
    {
        if (IsDisposed) return;
        BeginInvoke(() => status.Text = text);
    }

    private void SetHp(double? hp, string source = "")
    {
        if (IsDisposed) return;
        BeginInvoke(() => hpLabel.Text = hp.HasValue
            ? $"HP : {hp.Value:0} %" + (source.Length > 0 ? $" ({source})" : "")
            : "HP : --");
    }

    private async Task LoopAsync(CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            try
            {
                using var bmp = CaptureVirtualScreen();
                // One OCR pass per frame, shared by the text detection and the HP reading.
                var ocr = await OcrAsync(bmp);
                var text = ocr.Text ?? "";

                var reading = await DetectHpAsync(bmp, ocr);
                if (reading.Source == "carte familier" && lastHp.HasValue)
                {
                    // The companion temporarily occupies the player-card area.
                    // Keep the last verified player HP instead of reading the companion's HP.
                    reading = (lastHp, "PV joueur mémorisés (familier)");
                }
                if (reading.Hp.HasValue)
                {
                    lastHp = reading.Hp;
                    lastHpAt = DateTime.UtcNow;
                }
                else if (lastHp.HasValue && (DateTime.UtcNow - lastHpAt).TotalSeconds < 12)
                {
                    // The HP bar is often hidden by the victory popup: reuse the last reading from the fight.
                    reading = (lastHp, "mémorisé");
                }
                double? hp = reading.Hp;
                SetHp(hp, reading.Source);

                bool wantReturn = Contains(text, "RENTRER AU VILLAGE") && hp.HasValue && hp.Value < returnThreshold;
                if (!wantReturn) lowCount = 0;

                // Safety rule: only click a known target when its text is actually recognized.
                // Hero level-up popup: put exactly one point into Force, then confirm.
                if (Contains(text, "CONFIRMER") && Contains(text, "Force"))
                {
                    SetStatus("Niveau du héros : attente avant + Force");
                    await Task.Delay(2000, token);

                    // Capture a fresh screen after the wait, then click the green + on the Force row.
                    using var levelScreen = CaptureVirtualScreen();
                    bool forceClicked = await ClickForcePlusAsync(levelScreen, token);
                    if (forceClicked)
                    {
                        await Task.Delay(1200, token);
                        using var bmp2 = CaptureVirtualScreen();
                        var text2 = await ReadFrenchTextAsync(bmp2);
                        if (Contains(text2, "CONFIRMER"))
                        {
                            SetStatus("Force ajoutée : clic sur CONFIRMER");
                            await ClickConfirmAsync(bmp2, token);
                        }
                        else
                        {
                            SetStatus("Point Force cliqué, confirmation non détectée");
                        }
                    }
                    else
                    {
                        SetStatus("Niveau détecté, ligne Force introuvable : je n'ai pas confirmé");
                    }
                }
                // Portal button: enter the next area when this screen appears.
                else if (Contains(text, "FRANCHIR LE PORTAIL"))
                {
                    SetStatus("Portail détecté : franchissement");
                    await ClickTextAsync(bmp, text, "FRANCHIR LE PORTAIL", token);
                }
                // Event popups have priority over all gameplay buttons.
                else if (Contains(text, "COMPRIS"))
                {
                    SetStatus("Météo : compris !");
                    await ClickTextAsync(bmp, text, "COMPRIS", token);
                }
                // Companion level-up popup: close it first with "SUPER !".
                else if (Contains(text, "SUPER"))
                {
                    SetStatus("Niveau du compagnon : Super !");
                    await ClickTextAsync(bmp, text, "SUPER", token);
                }
                else if (wantReturn)
                {
                    // Require two consecutive low readings so one misread digit cannot send us home.
                    if (++lowCount >= 2)
                    {
                        lowCount = 0;
                        SetStatus($"PV sous {returnThreshold} % : retour au village");
                        await ClickTextAsync(bmp, text, "RENTRER AU VILLAGE", token);
                    }
                    else
                    {
                        SetStatus("PV bas détectés : vérification...");
                    }
                }
                else if (Contains(text, "CONTINUER") && hp.HasValue && hp.Value >= returnThreshold)
                {
                    SetStatus("Victoire : continuer");
                    await ClickTextAsync(bmp, text, "CONTINUER", token);
                }
                else if (Contains(text, "REPARTIR"))
                {
                    SetStatus("Rapport : repartir");
                    await ClickTextAsync(bmp, text, "REPARTIR", token);
                }
                else if (Contains(text, "PARTIR"))
                {
                    SetStatus("Préparation : partir");
                    await ClickTextAsync(bmp, text, "PARTIR", token);
                }
                else if (!hp.HasValue && (Contains(text, "RENTRER AU VILLAGE") || Contains(text, "CONTINUER")))
                {
                    SetStatus("PV illisibles : aucune action (capture sur le Bureau)");
                    DumpDebug(bmp, ocr);
                }
                else
                {
                    SetStatus("Analyse...");
                }

                await Task.Delay(900, token);
            }
            catch (OperationCanceledException) { break; }
            catch (Exception ex)
            {
                SetStatus("Erreur : " + ex.Message);
                await Task.Delay(1500, token);
            }
        }
    }

    private static bool Contains(string text, string wanted)
        => text.Replace("’", "'").IndexOf(wanted, StringComparison.OrdinalIgnoreCase) >= 0;

    private static Bitmap CaptureVirtualScreen()
    {
        var bounds = SystemInformation.VirtualScreen;
        var bmp = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format32bppArgb);
        using var g = Graphics.FromImage(bmp);
        g.CopyFromScreen(bounds.Left, bounds.Top, 0, 0, bounds.Size);
        return bmp;
    }

    private static async Task<OcrResult> OcrAsync(Bitmap bmp)
    {
        using var ms = new MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;
        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);
        var decoder = await BitmapDecoder.CreateAsync(ras);
        var softwareBitmap = await decoder.GetSoftwareBitmapAsync();
        var engine = SharedOcrEngine.Value;
        if (engine is null) throw new InvalidOperationException("OCR Windows indisponible (installer la langue française)");
        return await engine.RecognizeAsync(softwareBitmap);
    }

    // HP reading, three strategies from most to least reliable:
    //  1. "current / max" numbers in the full-screen OCR, next to the PV label
    //  2. same numbers read again on a 3x enlarged crop around the label (small text is the usual failure)
    //  3. fill ratio of the green bar, only if both ends of the bar are clearly delimited
    private static async Task<(double? Hp, string Source)> DetectHpAsync(Bitmap bmp, OcrResult full)
    {
        // The companion can temporarily replace the player card. If its name is
        // positively recognized, do not interpret its green bar as the player's HP.
        string cardText = string.Join(" ", full.Lines
            .Where(line =>
            {
                var r = GetLineRect(line);
                return r.Width > 0 && r.X < bmp.Width * 0.62 && r.Y < bmp.Height * 0.36;
            })
            .Select(line => line.Text));
        string normalizedCardText = NormalizeOcrIdentity(cardText);
        bool isCompanion = IdentityMatches(normalizedCardText, "CELESTE", 2);
        bool isPlayer = IdentityMatches(normalizedCardText, "SHOKKRYDER", 3);

        // Only pay for the enlarged header OCR when the full-screen pass cannot
        // identify either card. This avoids slowing every normal game loop.
        if (!isCompanion && !isPlayer)
        {
            string headerText = await ReadCardHeaderAsync(bmp);
            string normalizedHeader = NormalizeOcrIdentity(headerText);
            isCompanion = IdentityMatches(normalizedHeader, "CELESTE", 2);
        }
        if (isCompanion)
            return (null, "carte familier");

        // IMPORTANT: the PV label is tiny and Windows OCR often reads it as
        // "P", "PY" or misses it entirely. Find the actual long green HP bar
        // in the upper-left player card first. This works even when OCR misses
        // the label and adapts to both compact and expanded card layouts.
        var greenBar = FindPlayerGreenBar(bmp);
        if (greenBar.HasValue)
        {
            // Read the current/max digits directly above this detected bar.
            // The crop is anchored to the bar, not to a guessed screen Y value.
            var pair = await ReadPairNearGreenBarAsync(bmp, greenBar.Value);
            if (pair.HasValue)
                return (Percent(pair.Value), "PV joueur (chiffres près de la barre)");

            // If the digits are too small, use the measured green fill as a
            // percentage of the full player-card HP track.
            return (greenBar.Value.Percent, "barre PV joueur détectée");
        }

        // Secondary OCR fallback for themes/resolutions where the green colour
        // is altered. Only accept a PV label on the left-hand player card.
        var labels = new List<Windows.Foundation.Rect>();
        foreach (var line in full.Lines)
        foreach (var word in line.Words)
        {
            string token = Regex.Replace(word.Text.Trim().ToUpperInvariant(), @"[^A-Z]", "");
            if (token != "PV" && token != "PU" && token != "PY") continue;
            var r = word.BoundingRect;
            if (r.X < bmp.Width * 0.58 && r.Y > bmp.Height * 0.06 && r.Y < bmp.Height * 0.62
                && r.Width > 0 && r.Height > 0)
                labels.Add(r);
        }

        foreach (var label in labels.OrderBy(r => r.Y))
        {
            var pair = await ReadPairNearPvLabelAsync(bmp, label);
            if (pair.HasValue)
                return (Percent(pair.Value), "PV joueur (OCR de secours)");
        }

        return (null, "PV joueur non détectés");
    }

    private readonly record struct GreenBarReading(int X, int Y, int FillWidth, double Percent);

    private static GreenBarReading? FindPlayerGreenBar(Bitmap bmp)
    {
        // Search only the upper-left half where the player's card lives.
        // The XP bar is lower on the page and the enemy/familiar card is to the right.
        int x0 = Math.Clamp((int)(bmp.Width * 0.06), 0, bmp.Width - 1);
        int x1 = Math.Clamp((int)(bmp.Width * 0.59), x0 + 1, bmp.Width);
        int y0 = Math.Clamp((int)(bmp.Height * 0.06), 0, bmp.Height - 1);
        int y1 = Math.Clamp((int)(bmp.Height * 0.62), y0 + 1, bmp.Height);
        int w = x1 - x0, h = y1 - y0;
        if (w < 80 || h < 8) return null;

        var data = bmp.LockBits(new Rectangle(x0, y0, w, h), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        int stride = data.Stride;
        var buffer = new byte[Math.Abs(stride) * h];
        try { Marshal.Copy(data.Scan0, buffer, 0, buffer.Length); }
        finally { bmp.UnlockBits(data); }

        // A real HP bar produces a long, nearly horizontal green run across
        // several adjacent rows. Require a minimum width and prefer the
        // longest run, which rejects small green icons and the central + button.
        int bestRun = 0, bestX = 0, bestY = 0;
        for (int y = 0; y < h; y++)
        {
            int run = 0, runStart = 0;
            for (int x = 0; x < w; x++)
            {
                int i = y * stride + x * 4;
                int b = buffer[i], g = buffer[i + 1], r = buffer[i + 2];
                bool green = g >= 75 && g > r * 1.28 && g > b * 1.08;
                if (green)
                {
                    if (run == 0) runStart = x;
                    run++;
                    if (run > bestRun)
                    {
                        bestRun = run;
                        bestX = runStart;
                        bestY = y;
                    }
                }
                else run = 0;
            }
        }

        // Reject decorative green marks. A player HP fill is a substantial
        // horizontal strip, even when the player is badly injured.
        int minimumRun = Math.Max(3, (int)(bmp.Width * 0.008));
        if (bestRun < minimumRun) return null;

        // In both supplied layouts the HP track occupies about 30% of the
        // captured desktop width inside the left card. The scan is restricted
        // to that card, so the right-hand creature's HP cannot be selected.
        double trackWidth = bmp.Width * 0.305;
        double percent = Math.Clamp(100.0 * bestRun / trackWidth, 0, 100);
        return new GreenBarReading(x0 + bestX, y0 + bestY, bestRun, percent);
    }

    private static async Task<(int Current, int Maximum)?> ReadPairNearGreenBarAsync(
        Bitmap bmp, GreenBarReading bar)
    {
        // The numeric pair is printed immediately above the green strip.
        int x0 = Math.Max(0, bar.X - (int)(bmp.Width * 0.015));
        int y0 = Math.Max(0, bar.Y - (int)(bmp.Height * 0.055));
        int x1 = Math.Min((int)(bmp.Width * 0.58), x0 + (int)(bmp.Width * 0.40));
        int y1 = Math.Min(bmp.Height, bar.Y + Math.Max(5, (int)(bmp.Height * 0.012)));
        int w = x1 - x0, h = y1 - y0;
        if (w < 40 || h < 6) return null;

        const int scale = 4;
        foreach (bool invert in new[] { false, true })
        {
            using var zoom = new Bitmap(w * scale, h * scale, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(zoom))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.DrawImage(bmp, new Rectangle(0, 0, zoom.Width, zoom.Height),
                    new Rectangle(x0, y0, w, h), GraphicsUnit.Pixel);
            }
            if (invert) GrayInvert(zoom);
            var result = await OcrAsync(zoom);
            foreach (var line in result.Lines)
            {
                var pair = ParseHpPair(line.Text);
                if (pair.HasValue) return pair;
            }
            var all = ParseHpPair(result.Text ?? "");
            if (all.HasValue) return all;
        }
        return null;
    }

    private static string NormalizeOcrIdentity(string value)
    {
        string decomposed = value.Normalize(NormalizationForm.FormD);
        var chars = decomposed.Where(c => System.Globalization.CharUnicodeInfo.GetUnicodeCategory(c)
            != System.Globalization.UnicodeCategory.NonSpacingMark).ToArray();
        return Regex.Replace(new string(chars).ToUpperInvariant(), @"[^A-Z0-9]", "");
    }

    private static bool IdentityMatches(string text, string expected, int maxDistance)
    {
        if (text.Contains(expected, StringComparison.Ordinal)) return true;
        // OCR may insert, omit or confuse a few characters. Compare only sufficiently
        // long tokens so unrelated card text cannot accidentally identify the player.
        foreach (Match token in Regex.Matches(text, @"[A-Z0-9]{6,}"))
        {
            if (EditDistance(token.Value, expected) <= maxDistance) return true;
        }
        return false;
    }

    private static int EditDistance(string a, string b)
    {
        var previous = Enumerable.Range(0, b.Length + 1).ToArray();
        var current = new int[b.Length + 1];
        for (int i = 1; i <= a.Length; i++)
        {
            current[0] = i;
            for (int j = 1; j <= b.Length; j++)
                current[j] = Math.Min(Math.Min(current[j - 1] + 1, previous[j] + 1),
                    previous[j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1));
            (previous, current) = (current, previous);
        }
        return previous[b.Length];
    }

    private static async Task<string> ReadCardHeaderAsync(Bitmap bmp)
    {
        // Name is in the upper portion of the left-hand card. Coordinates are relative
        // to the captured desktop, so the crop scales with window/screen resolution.
        int x0 = Math.Clamp((int)(bmp.Width * 0.04), 0, bmp.Width - 1);
        int y0 = Math.Clamp((int)(bmp.Height * 0.035), 0, bmp.Height - 1);
        int w = Math.Min(bmp.Width - x0, Math.Max(1, (int)(bmp.Width * 0.48)));
        int h = Math.Min(bmp.Height - y0, Math.Max(1, (int)(bmp.Height * 0.22)));
        if (w < 20 || h < 10) return "";

        using var zoom = new Bitmap(w * 3, h * 3, PixelFormat.Format32bppArgb);
        using (var g = Graphics.FromImage(zoom))
        {
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.DrawImage(bmp, new Rectangle(0, 0, zoom.Width, zoom.Height),
                new Rectangle(x0, y0, w, h), GraphicsUnit.Pixel);
        }
        var result = await OcrAsync(zoom);
        return result.Text ?? "";
    }

    private static async Task<(int Current, int Maximum)?> ReadPlayerHpCropAsync(Bitmap bmp)
    {
        // Relative coordinates keep this usable at different desktop resolutions.
        // New Hife card layout: the PV label and current/max pair sit below
        // the portrait, above the purple Mana row. Keep this crop inside the
        // left player card and away from the companion/enemy card.
        int x0 = Math.Clamp((int)(bmp.Width * 0.08), 0, bmp.Width - 1);
        int y0 = Math.Clamp((int)(bmp.Height * 0.12), 0, bmp.Height - 1);
        int w = Math.Min(bmp.Width - x0, Math.Max(1, (int)(bmp.Width * 0.44)));
        int h = Math.Min(bmp.Height - y0, Math.Max(1, (int)(bmp.Height * 0.13)));
        if (w < 20 || h < 10) return null;

        const int scale = 4;
        foreach (bool invert in new[] { false, true })
        {
            using var zoom = new Bitmap(w * scale, h * scale, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(zoom))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.DrawImage(bmp, new Rectangle(0, 0, zoom.Width, zoom.Height),
                            new Rectangle(x0, y0, w, h), GraphicsUnit.Pixel);
            }
            if (invert) GrayInvert(zoom);

            var result = await OcrAsync(zoom);
            foreach (var line in result.Lines)
            {
                var pair = ParseHpPair(line.Text);
                if (pair.HasValue) return pair;
            }

            var wholeTextPair = ParseHpPair(result.Text ?? "");
            if (wholeTextPair.HasValue) return wholeTextPair;
        }
        return null;
    }

    // Last-resort reading from the player's GREEN PV BAR itself. The bar is
    // in the fixed PV row directly above Mana on the left player card.
    // This avoids depending on OCR recognizing the tiny "PV" label or digits.
    private static double? ReadPlayerGreenHpBar(Bitmap bmp)
    {
        int x0 = Math.Clamp((int)(bmp.Width * 0.075), 0, bmp.Width - 1);
        int x1 = Math.Clamp((int)(bmp.Width * 0.425), x0 + 1, bmp.Width);
        int y0 = Math.Clamp((int)(bmp.Height * 0.135), 0, bmp.Height - 1);
        int y1 = Math.Clamp((int)(bmp.Height * 0.205), y0 + 1, bmp.Height);
        int w = x1 - x0, h = y1 - y0;
        if (w < 80 || h < 3) return null;

        var data = bmp.LockBits(new Rectangle(x0, y0, w, h), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        int stride = data.Stride;
        var buffer = new byte[Math.Abs(stride) * h];
        try { Marshal.Copy(data.Scan0, buffer, 0, buffer.Length); }
        finally { bmp.UnlockBits(data); }

        int bestRun = 0;
        for (int y = 0; y < h; y++)
        {
            int run = 0;
            for (int x = 0; x < w; x++)
            {
                int i = y * stride + x * 4;
                int b = buffer[i], g = buffer[i + 1], r = buffer[i + 2];
                bool green = g > 75 && g > r * 1.30 && g > b * 1.12;
                run = green ? run + 1 : 0;
                if (run > bestRun) bestRun = run;
            }
        }

        // The PV track spans almost the full inner width of the player card.
        // Reject tiny green decorations/highlights elsewhere in this narrow row.
        double trackWidth = bmp.Width * 0.305;
        if (bestRun < trackWidth * 0.12) return null;
        return Math.Clamp(100.0 * bestRun / trackWidth, 0, 100);
    }

    private static double Percent((int Current, int Maximum) p)
        => Math.Clamp(100.0 * p.Current / p.Maximum, 0, 100);

    private static async Task<(int Current, int Maximum)?> ZoomReadPairAsync(Bitmap bmp, Windows.Foundation.Rect label)
    {
        int x0 = Math.Max(0, (int)label.X - 10);
        int y0 = Math.Max(0, (int)(label.Y - label.Height));
        int w = Math.Min(bmp.Width - x0, Math.Max(400, (int)(bmp.Width * 0.5)));
        int h = Math.Min(bmp.Height - y0, Math.Max(24, (int)(label.Height * 4)));
        if (w < 20 || h < 10) return null;
        const int scale = 3;

        foreach (bool invert in new[] { false, true })
        {
            using var zoom = new Bitmap(w * scale, h * scale, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(zoom))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.DrawImage(bmp, new Rectangle(0, 0, zoom.Width, zoom.Height),
                            new Rectangle(x0, y0, w, h), GraphicsUnit.Pixel);
            }
            if (invert) GrayInvert(zoom);
            var res = await OcrAsync(zoom);
            foreach (var line in res.Lines)
            {
                var pair = ParseHpPair(line.Text);
                if (pair.HasValue) return pair;
            }
        }
        return null;
    }

    // Light text on a dark/coloured background is hard for the Windows OCR: give it dark text on light.
    private static void GrayInvert(Bitmap bmp)
    {
        var rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        var data = bmp.LockBits(rect, ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
        try
        {
            var buf = new byte[Math.Abs(data.Stride) * bmp.Height];
            Marshal.Copy(data.Scan0, buf, 0, buf.Length);
            for (int y = 0; y < bmp.Height; y++)
            {
                int row = y * data.Stride;
                for (int x = 0; x < bmp.Width; x++)
                {
                    int i = row + x * 4;
                    int gray = (buf[i + 2] * 30 + buf[i + 1] * 59 + buf[i] * 11) / 100;
                    byte v = (byte)(255 - gray);
                    buf[i] = buf[i + 1] = buf[i + 2] = v;
                    buf[i + 3] = 255;
                }
            }
            Marshal.Copy(buf, 0, data.Scan0, buf.Length);
        }
        finally { bmp.UnlockBits(data); }
    }

    // Measures green / (green + empty part) on the row where the green run is longest.
    // Returns null unless the right end of the bar is delimited by a bright frame, so a dark
    // background can never be mistaken for an empty bar.
    private static double? MeasureBar(Bitmap bmp, Windows.Foundation.Rect label)
    {
        int x0 = Math.Max(0, (int)label.X - 20);
        int y0 = Math.Max(0, (int)(label.Y - label.Height * 0.5));
        int x1 = Math.Min(bmp.Width, (int)(label.X + bmp.Width * 0.45));
        int y1 = Math.Min(bmp.Height, (int)(label.Y + label.Height * 3.5));
        int w = x1 - x0, h = y1 - y0;
        if (w < 80 || h < 4) return null;

        var data = bmp.LockBits(new Rectangle(x0, y0, w, h), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        int stride = data.Stride;
        var buf = new byte[Math.Abs(stride) * h];
        try { Marshal.Copy(data.Scan0, buf, 0, buf.Length); }
        finally { bmp.UnlockBits(data); }

        bool IsGreen(int x, int y)
        {
            int i = y * stride + x * 4;
            int b = buf[i], g = buf[i + 1], r = buf[i + 2];
            return g > 65 && g > r * 1.25 && g > b * 1.08;
        }
        int Max(int x, int y)
        {
            int i = y * stride + x * 4;
            return Math.Max(buf[i], Math.Max(buf[i + 1], buf[i + 2]));
        }

        double? best = null;
        int bestGreen = 0;
        for (int y = 0; y < h; y++)
        {
            int run = 0, runStart = 0, gap = 0, bestRun = 0, bs = 0, be = 0;
            for (int x = 0; x < w; x++)
            {
                if (IsGreen(x, y))
                {
                    if (run == 0) runStart = x;
                    run++; gap = 0;
                    if (run > bestRun) { bestRun = run; bs = runStart; be = x; }
                }
                else if (run > 0 && ++gap > 2) { run = 0; gap = 0; }
            }
            if (bestRun < 4 || bestRun <= bestGreen) continue;

            int e = be + 1, bright = 0;
            bool bounded = false;
            while (e < w)
            {
                if (IsGreen(e, y)) { be = e; bright = 0; }
                else if (Max(e, y) >= 140)
                {
                    if (++bright >= 2) { bounded = true; break; }
                }
                else bright = 0;
                e++;
            }
            if (!bounded) continue;
            int trackEnd = Math.Max(be + 1, e - 1);
            int track = trackEnd - bs;
            if (track < 80) continue;

            bestGreen = bestRun;
            best = Math.Clamp(100.0 * (be - bs + 1) / track, 0, 100);
        }
        return best;
    }

    private static void DumpDebug(Bitmap bmp, OcrResult ocr)
    {
        try
        {
            if (dumpCount >= 12 || (DateTime.Now - lastDump).TotalSeconds < 5) return;
            lastDump = DateTime.Now;
            dumpCount++;
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "CelestBot_debug");
            Directory.CreateDirectory(dir);
            var stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            bmp.Save(Path.Combine(dir, stamp + ".png"), ImageFormat.Png);
            var sb = new StringBuilder();
            foreach (var line in ocr.Lines)
            {
                var r = GetLineRect(line);
                sb.AppendLine($"{r.X:0},{r.Y:0},{r.Width:0},{r.Height:0} | {line.Text}");
            }
            File.WriteAllText(Path.Combine(dir, stamp + ".txt"), sb.ToString());
        }
        catch { /* debug only */ }
    }

    private static DateTime lastDump = DateTime.MinValue;
    private static int dumpCount;

    // WinRT OcrLine does not expose BoundingRect directly. Build it from the
    // bounding rectangles of its recognized words.
    private static Windows.Foundation.Rect GetLineRect(OcrLine line)
    {
        var words = line.Words;
        if (words.Count == 0)
            return new Windows.Foundation.Rect(0, 0, 0, 0);

        double left = words.Min(w => w.BoundingRect.X);
        double top = words.Min(w => w.BoundingRect.Y);
        double right = words.Max(w => w.BoundingRect.X + w.BoundingRect.Width);
        double bottom = words.Max(w => w.BoundingRect.Y + w.BoundingRect.Height);
        return new Windows.Foundation.Rect(left, top, right - left, bottom - top);
    }

    private static (int Current, int Maximum)? ParseHpPair(string text)
    {
        // OCR often turns 0 into O and 1 into I / l / | in small game fonts.
        var t = text.Replace('O', '0').Replace('o', '0').Replace('I', '1').Replace('l', '1').Replace('|', '1')
                    .Replace(' ', ' ');
        const string num = @"(?:\d{1,3}(?:[ .,]\d{3})+|\d+)";
        var match = Regex.Match(t, $@"(?<cur>{num})\s*[/\\]\s*(?<max>{num})");
        if (!match.Success) return null;
        static bool TryDigits(string value, out int number)
            => int.TryParse(Regex.Replace(value, @"[^0-9]", ""), out number);
        if (!TryDigits(match.Groups["cur"].Value, out int current) ||
            !TryDigits(match.Groups["max"].Value, out int maximum) || maximum <= 0 || current > maximum)
            return null;
        return (current, maximum);
    }

    private static async Task<string> ReadFrenchTextAsync(Bitmap bmp)
    {
        using var ms = new System.IO.MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;

        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);

        var decoder = await BitmapDecoder.CreateAsync(ras);
        var sb = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
                     ?? OcrEngine.TryCreateFromUserProfileLanguages();

        var result = await engine.RecognizeAsync(sb);
        return result.Text ?? "";
    }

    private static async Task<bool> ClickForcePlusAsync(Bitmap bmp, CancellationToken token)
    {
        using var ms = new System.IO.MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;

        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);

        var decoder = await BitmapDecoder.CreateAsync(ras);
        var sb = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
                     ?? OcrEngine.TryCreateFromUserProfileLanguages();
        var result = await engine.RecognizeAsync(sb);

        foreach (var line in result.Lines)
        {
            if (line.Text.IndexOf("Force", StringComparison.OrdinalIgnoreCase) < 0)
                continue;

            var rects = line.Words.Select(w => w.BoundingRect).ToArray();
            if (rects.Length == 0) continue;

            double top = rects.Min(r => r.Y);
            double bottom = rects.Max(r => r.Y + r.Height);
            int y = (int)((top + bottom) / 2);

            // The green + is to the right of the grey minus. Use the right-hand button,
            // not the previous coordinate which landed too far left.
            int x = (int)(bmp.Width * 0.68);

            NativeClick.Click(x + SystemInformation.VirtualScreen.Left,
                              y + SystemInformation.VirtualScreen.Top);
            await Task.Delay(300, token);
            return true;
        }
        return false;
    }

    private static async Task ClickConfirmAsync(Bitmap bmp, CancellationToken token)
    {
        using var ms = new System.IO.MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;
        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);
        var decoder = await BitmapDecoder.CreateAsync(ras);
        var sb = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
                     ?? OcrEngine.TryCreateFromUserProfileLanguages();
        var result = await engine.RecognizeAsync(sb);
        foreach (var line in result.Lines)
        {
            if (line.Text.IndexOf("CONFIRMER", StringComparison.OrdinalIgnoreCase) < 0)
                continue;
            var rects = line.Words.Select(w => w.BoundingRect).ToArray();
            if (rects.Length == 0) continue;
            int x = (int)((rects.Min(r => r.X) + rects.Max(r => r.X + r.Width)) / 2);
            int y = (int)((rects.Min(r => r.Y) + rects.Max(r => r.Y + r.Height)) / 2);
            NativeClick.Click(x + SystemInformation.VirtualScreen.Left,
                              y + SystemInformation.VirtualScreen.Top);
            await Task.Delay(1400, token);
            return;
        }
        // Fallback for the supplied portrait layout when OCR misses the button label.
        int fallbackX = (int)(bmp.Width * 0.50);
        int fallbackY = (int)(bmp.Height * 0.91);
        NativeClick.Click(fallbackX + SystemInformation.VirtualScreen.Left,
                          fallbackY + SystemInformation.VirtualScreen.Top);
        await Task.Delay(1400, token);
    }

    private static async Task ClickTextAsync(Bitmap bmp, string fullText, string wanted, CancellationToken token)
    {
        // Re-run OCR with word boxes so we can click the recognized button itself.
        using var ms = new System.IO.MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;

        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);

        var decoder = await BitmapDecoder.CreateAsync(ras);
        var sb = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
                     ?? OcrEngine.TryCreateFromUserProfileLanguages();
        var result = await engine.RecognizeAsync(sb);

        var normalizedWanted = wanted.Replace("!", "").Trim();
        foreach (var line in result.Lines)
        {
            var lineText = line.Text.Replace("!", "").Trim();
            if (lineText.IndexOf(normalizedWanted, StringComparison.OrdinalIgnoreCase) < 0)
                continue;

            var rect = line.Words.Select(w => w.BoundingRect).ToArray();
            if (rect.Length == 0) continue;

            double left = rect.Min(r => r.X);
            double top = rect.Min(r => r.Y);
            double right = rect.Max(r => r.X + r.Width);
            double bottom = rect.Max(r => r.Y + r.Height);

            int x = (int)((left + right) / 2);
            int y = (int)((top + bottom) / 2);

            // Avoid accidental clicks near screen edges.
            if (x < 5 || y < 5 || x >= bmp.Width - 5 || y >= bmp.Height - 5) return;

            NativeClick.Click(x + SystemInformation.VirtualScreen.Left,
                              y + SystemInformation.VirtualScreen.Top);
            await Task.Delay(1400, token);
            return;
        }
    }
}
